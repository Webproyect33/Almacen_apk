import React, { useState, useEffect } from 'react';
import {
  Warehouse,
  Home as HomeIcon,
  Boxes,
  ArrowDownToLine,
  ArrowUpFromLine,
  Settings,
  RotateCcw
} from 'lucide-react';

export default function App() {
  const [showSplash, setShowSplash] = useState<boolean>(true);
  const [progress, setProgress] = useState<number>(0);
  const [activeTab, setActiveTab] = useState<number>(0);

  // Splash screen de 3 segundos exactos (3000ms) con barra de progreso
  useEffect(() => {
    if (!showSplash) return;

    setProgress(0);
    const totalDuration = 3000;
    const intervalTime = 50;
    const increment = 100 / (totalDuration / intervalTime);

    const progressTimer = setInterval(() => {
      setProgress((prev) => {
        const next = prev + increment;
        if (next >= 100) {
          clearInterval(progressTimer);
          return 100;
        }
        return next;
      });
    }, intervalTime);

    const splashTimeout = setTimeout(() => {
      setShowSplash(false);
    }, totalDuration);

    return () => {
      clearInterval(progressTimer);
      clearTimeout(splashTimeout);
    };
  }, [showSplash]);

  const navButtons = [
    { id: 0, label: 'Inicio', icon: HomeIcon },
    { id: 1, label: 'Inventario', icon: Boxes },
    { id: 2, label: 'Entradas', icon: ArrowDownToLine },
    { id: 3, label: 'Salidas', icon: ArrowUpFromLine },
    { id: 4, label: 'Ajustes', icon: Settings },
  ];

  // 1. Splash Screen
  if (showSplash) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-950 flex flex-col items-center justify-center p-6 text-white select-none">
        <div className="w-full max-w-sm flex flex-col items-center text-center">
          <div className="relative mb-8">
            <div className="w-28 h-28 rounded-3xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center shadow-2xl shadow-blue-500/10 backdrop-blur-md animate-pulse">
              <Warehouse className="w-16 h-16 text-blue-400 stroke-[1.75]" />
            </div>
          </div>

          <h1 className="text-3xl font-bold tracking-tight text-white mb-2">
            Broters_Almacen
          </h1>
          <p className="text-sm font-medium text-slate-400 mb-8">
            Cargando sistema de gestión...
          </p>

          <div className="w-full bg-slate-700/60 rounded-full h-3 overflow-hidden p-0.5 border border-slate-600/40 shadow-inner">
            <div
              className="bg-gradient-to-r from-blue-500 to-cyan-400 h-full rounded-full transition-all duration-75 ease-linear"
              style={{ width: `${Math.min(progress, 100)}%` }}
            />
          </div>

          <div className="mt-3 flex justify-between w-full text-xs font-mono text-slate-400">
            <span>Iniciando...</span>
            <span>{Math.round(Math.min(progress, 100))}%</span>
          </div>
        </div>
      </div>
    );
  }

  // 2. Pantalla Principal (Home) con menú fijo inferior de 5 botones
  return (
    <div className="min-h-screen bg-slate-100 flex flex-col text-slate-800">
      <header className="sticky top-0 z-30 bg-white border-b border-slate-200 px-4 py-3 shadow-xs">
        <div className="max-w-md mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-sm">
              <Warehouse className="w-5 h-5 stroke-[2]" />
            </div>
            <div>
              <h1 className="font-bold text-base text-slate-900 leading-tight">
                Broters_Almacen
              </h1>
              <p className="text-xs text-slate-500 font-medium">
                Panel Principal
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowSplash(true)}
            className="flex items-center gap-1.5 text-xs text-slate-600 hover:text-blue-600 bg-slate-100 hover:bg-slate-200 px-2.5 py-1.5 rounded-lg font-medium transition-colors"
            title="Volver a ver Splash Screen"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Ver Splash</span>
          </button>
        </div>
      </header>

      <main className="flex-1 max-w-md w-full mx-auto p-4 pb-24">
        <div className="bg-white rounded-2xl p-5 shadow-xs border border-slate-200 mb-4">
          <div className="flex items-center gap-3">
            {React.createElement(navButtons[activeTab].icon, {
              className: 'w-7 h-7 text-blue-600',
            })}
            <div>
              <h2 className="text-lg font-bold text-slate-900">
                {navButtons[activeTab].label}
              </h2>
              <p className="text-xs text-slate-500">
                Sección activa en Broters_Almacen
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-6 shadow-xs border border-slate-200 text-center flex flex-col items-center justify-center min-h-[220px]">
          <div className="w-16 h-16 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mb-3">
            <Warehouse className="w-8 h-8 stroke-[1.75]" />
          </div>
          <h3 className="text-base font-semibold text-slate-900 mb-1">
            Bienvenido a Broters_Almacen
          </h3>
          <p className="text-xs text-slate-500 max-w-xs leading-relaxed">
            Has seleccionado la opción: <strong className="text-slate-800">{navButtons[activeTab].label}</strong>. Utiliza el menú inferior fijo de 5 botones para navegar.
          </p>
        </div>
      </main>

      <nav className="fixed bottom-0 inset-x-0 bg-white border-t border-slate-200 shadow-lg z-40">
        <div className="max-w-md mx-auto grid grid-cols-5 h-16 px-1">
          {navButtons.map((btn) => {
            const Icon = btn.icon;
            const isActive = activeTab === btn.id;
            return (
              <button
                key={btn.id}
                onClick={() => setActiveTab(btn.id)}
                type="button"
                className={`flex flex-col items-center justify-center py-1 transition-all duration-150 ${
                  isActive
                    ? 'text-blue-600 font-semibold'
                    : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                <div
                  className={`p-1 rounded-xl transition-colors ${
                    isActive ? 'bg-blue-50' : 'bg-transparent'
                  }`}
                >
                  <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.2]' : 'stroke-[1.75]'}`} />
                </div>
                <span className="text-[10px] mt-0.5 tracking-tight truncate max-w-full px-1">
                  {btn.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
