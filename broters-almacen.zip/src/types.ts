export interface Product {
  id: string;
  name: string;
  buyPrice: number;
  sellPrice: number;
  stock: number;
  category: string;
  createdAt: string;
  updatedAt: string;
}

export interface Category {
  id: string;
  name: string;
  description?: string;
  color?: string;
  createdAt: string;
}

export interface Salesperson {
  id: string;
  username: string;
  name: string;
  password: string; // En texto o encriptado simple para visualización/reinicio por el administrador
  phone?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface ReportItem {
  productId: string;
  productName: string;
  quantity: number;
  buyPrice: number;
  sellPrice: number;
  subtotal: number;
}

export interface SaleReport {
  id: string;
  salespersonId: string;
  salespersonName: string;
  items: ReportItem[];
  totalAmount: number;
  totalCost: number;
  totalProfit: number;
  date: string; // formato YYYY-MM-DD
  timestamp: string; // ISO
  notes?: string;
}

export type ActionType =
  | 'create'
  | 'edit'
  | 'add_stock'
  | 'delete'
  | 'category_create'
  | 'category_edit'
  | 'category_delete'
  | 'salesperson_create'
  | 'salesperson_edit'
  | 'salesperson_reset_pass'
  | 'report_create';

export interface ActivityLog {
  id: string;
  timestamp: string;
  actionType: ActionType;
  productId?: string;
  productName: string;
  description: string;
  details: {
    previousStock?: number;
    newStock?: number;
    addedStock?: number;
    previousData?: any;
    newData?: any;
    note?: string;
  };
}
